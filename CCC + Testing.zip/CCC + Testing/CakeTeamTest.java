package CCC2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class CakeTeamTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void addMember() {
    }

    @Test
    void getTotalRaised() {
    }

    @Test
    void getTeamDetails() {
    }

    @Test
    void getMoney() {
    }

    @Test
    void sortTeam() {
    }

    @Test
    void getTotalCakes() {
    }
}