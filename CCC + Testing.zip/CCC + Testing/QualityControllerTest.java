package CCC2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QualityControllerTest {

    @Test
    void getCakesCovered() {
    }

    @Test
    void getAmount() {
    }

    @Test
    void getName() {
    }

    @Test
    void testToString() {
    }

    @Test
    void compareTo() {
    }

    @Test
    void addCakes() {
    }

    @Test
    void removeCakes() {
    }

    @Test
    void testGetAmount() {
    }

    @Test
    void testGetName() {
    }

    @Test
    void testToString1() {
    }

    @Test
    void testCompareTo() {
    }

    @Test
    void testAddCakes() {
    }

    @Test
    void testRemoveCakes() {
    }
}